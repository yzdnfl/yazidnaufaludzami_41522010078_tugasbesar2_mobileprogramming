package com.example.yazidnaufalhudzami_41522010078_tugasbesar2.features.taken_subject_crud;

public interface TakenSubjectCrudListener {
    void onTakenSubjectUpdated(boolean isUpdated);
}
