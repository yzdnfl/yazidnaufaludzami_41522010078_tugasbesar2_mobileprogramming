package com.example.yazidnaufalhudzami_41522010078_tugasbesar2.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
