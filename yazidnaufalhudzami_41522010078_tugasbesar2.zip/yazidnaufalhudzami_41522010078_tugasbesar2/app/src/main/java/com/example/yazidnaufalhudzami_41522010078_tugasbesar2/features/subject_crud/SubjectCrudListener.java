package com.example.yazidnaufalhudzami_41522010078_tugasbesar2.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}
